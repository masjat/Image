package com.example.mobileprograming

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mobileprograming.ui.theme.MobileProgramingTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MobileProgramingTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                Imagee(pesan = "Happy Graduation Anny!!", pengirim = "From Carl" )
                }
            }
        }
    }
}

@Composable
fun GreettingText(pesan : String, pengirim : String, modifier: Modifier = Modifier) {
    Column (
        verticalArrangement = Arrangement.Center,
        modifier = modifier.padding(8.dp)
            ){

        Text(
            text = pesan,
            fontSize = 70.sp,
            lineHeight = 110.sp,
            textAlign = TextAlign.Center,

            )
        Text(
            text = pengirim,
            fontSize = 28.sp,
            modifier = Modifier
                .padding(16.dp)
                .align(alignment = Alignment.End)
            )
    }
}
@Composable
fun Imagee(pesan : String, pengirim : String, modifier: Modifier = Modifier){
    val gambar = painterResource(R.drawable.foto)
    Box {
        Image(
            painter = gambar,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            alpha = 0.9F,
            contentScale = ContentScale.Crop
        )
        GreettingText(
            pesan = pesan,
            pengirim =pengirim,
            modifier =Modifier.fillMaxSize().padding(5.dp))
    }
}
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MobileProgramingTheme {
        Imagee("Happy Graduation Anny!!",
        pengirim = " From Carl")
    }
}